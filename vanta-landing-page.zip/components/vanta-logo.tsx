export function VantaMark({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M4 5.5h5.4L16 22.4 22.6 5.5H28L18.4 28.5h-4.8L4 5.5Z"
        fill="currentColor"
      />
      <path d="M13.2 5.5h5.6L16 12.6l-2.8-7.1Z" fill="currentColor" opacity="0.45" />
    </svg>
  )
}

export function VantaLogo({ className }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2.5 ${className ?? ''}`}>
      <VantaMark className="h-5 w-5 text-white" />
      <span className="font-display text-[0.95rem] font-bold tracking-[0.42em] text-white">
        VANTA
      </span>
    </div>
  )
}
